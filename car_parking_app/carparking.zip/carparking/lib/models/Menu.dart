class Menu {
  String menu_icon, menu_name;

  Menu(this.menu_icon, this.menu_name);
}
