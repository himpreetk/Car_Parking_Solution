class UserInfoModel {


  String user_email, user_group, user_name, user_contact, location, active_status, credit;

  UserInfoModel(this.user_email, this.user_group, this.user_name,
      this.user_contact, this.location, this.active_status, this.credit);
}
