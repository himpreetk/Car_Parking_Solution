class UsersModel {


  String user_email, user_group, user_name, user_contact, location, active_status, vehicle_no;

  UsersModel(this.user_email, this.user_group, this.user_name,
      this.user_contact, this.location, this.active_status, this.vehicle_no);
}
