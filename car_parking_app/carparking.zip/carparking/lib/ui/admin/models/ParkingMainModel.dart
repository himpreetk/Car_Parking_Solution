class ParkingMainModel {
  String parking_name, parking_city, parking_address, parking_row_num;

  ParkingMainModel(this.parking_name, this.parking_city, this.parking_address,
      this.parking_row_num);
}
