class ParkingRowModel {
  String parking_name, parking_row_name, parking_col_num, parking_row_type;

  ParkingRowModel(this.parking_name, this.parking_row_name,
      this.parking_col_num, this.parking_row_type);
}
