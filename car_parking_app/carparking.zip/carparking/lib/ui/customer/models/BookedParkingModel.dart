class BookedParkingModel {
  String parking_name, selected_row, row_col_name, date_added, location, user_email, user_name, user_contact;

  BookedParkingModel(
      this.parking_name,
      this.selected_row,
      this.row_col_name,
      this.date_added,
      this.location,
      this.user_email,
      this.user_name,
      this.user_contact);
}
