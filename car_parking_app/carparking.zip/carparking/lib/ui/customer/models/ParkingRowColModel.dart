class ParkingRowColModel {
  String parking_name, parking_row_name, parking_row_col_val;

  ParkingRowColModel(
      this.parking_name, this.parking_row_name, this.parking_row_col_val);
}
