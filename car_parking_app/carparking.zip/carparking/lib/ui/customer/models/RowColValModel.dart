class RowColValModel {
  String row_col_name, is_occupied;

  RowColValModel(this.row_col_name, this.is_occupied);
}
