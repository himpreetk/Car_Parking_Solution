class ParkingRowTypeModel {
  String parking_name, parking_row_name, parking_row_type;

  ParkingRowTypeModel(
      this.parking_name, this.parking_row_name, this.parking_row_type);
}
