class ParkingRowModel {
  String parking_name, city, address, rows;

  ParkingRowModel(this.parking_name, this.city, this.address, this.rows);
}
