package com.parking.carparking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
